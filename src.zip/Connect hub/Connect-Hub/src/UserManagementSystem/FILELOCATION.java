package UserManagementSystem;

public interface FILELOCATION {
    String DATABASE = "C:\\Users\\ADMIN\\Downloads\\UserManagementSystem\\src\\usermanagementsystem\\database.json";
}
