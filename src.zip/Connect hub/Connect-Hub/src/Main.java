
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */



import UserManagementSystem.Firstpage;
public class Main {
    public static void main(String[] args) {
        Firstpage fp = new Firstpage();
        fp.setTitle("FirstPage");
            fp.setVisible(true);

    }
}
