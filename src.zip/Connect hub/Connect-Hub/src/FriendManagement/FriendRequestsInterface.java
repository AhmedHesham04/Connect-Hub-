package FriendManagement;


public interface FriendRequestsInterface {

    public void sendFriendRequest();
    public void acceptFriendRequestStatus();
    public void removeFriendRequestStatus();
    
}
