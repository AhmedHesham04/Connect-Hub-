/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ContentCreation;

public interface FILELOCATION {
    String DATABASE = "/home/dandy/Desktop/Connect hub/Connect-Hub/DATABASE/users.json";
}
